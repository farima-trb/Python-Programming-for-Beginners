import csv
from collections import OrderedDict
from statistics import mean

#--------------------------------------------------------------DONE--------------------------------------------------------------------
#task1
def calculate_averages(input_file_name,output_file_name):
	#making a dictionary that includes name and mean --> {'mandana':7.5, ...}
	with open(input_file_name) as f:
		rows=csv.reader(f)
		dic=OrderedDict()
		for r in rows:
			name=r[0]
			grades=[]
			for g in r[1:]:
				grades.append(float(g))
			dic.update({name: mean(grades)})
	#import dictionary in output file
	resfile=open(output_file_name,"w",newline="")
	writer = csv.writer(resfile)
	for key,value in dic.items():
		writer.writerow([key,value])

	return output_file_name
#call the func:	
# calculate_averages("input_file_name","output_file_name")

#-------------------------------------------------------------------DONE-----------------------------------------------------------------
#task2
def calculate_sorted_averages(input_file_name,output_file_name):
	#making a dictionary that includes name and mean --> {'mandana':7.5, ...}
	with open(input_file_name) as f:
		rows=csv.reader(f)
		dic=OrderedDict()
		for r in rows:
			name=r[0]
			grades=[]
			for g in r[1:]:
				grades.append(float(g))
			dic.update({name: mean(grades)})

	dic3=dict(dic)
	list3= [[k,v] for k,v in dic3.items()]
	for i in range(0,len(list3)):
		temp=list3[i][0]
		list3[i][0]=list3[i][1]
		list3[i][1]=temp
	list3.sort()
	for i in range(0,len(list3)):
		temp=list3[i][0]
		list3[i][0]=list3[i][1]
		list3[i][1]=temp
	
	with open(output_file_name, 'w', newline='') as csvfile:
		writer = csv.writer(csvfile)
		for i in list3:
			writer.writerows([i])

	return output_file_name		

#-----------------------------------------------------------------------DONE-----------------------------------------------------------    

#task3: name ,top3 mean
def calculate_three_best(input_file_name,output_file_name):   
    with open(input_file_name) as f:
        rows=csv.reader(f)
        dic=OrderedDict()
        for r in rows:
            name=r[0]
            grades=[]
            for g in r[1:]:
                grades.append(float(g))
            dic.update({name: mean(grades)})

    dic3=dict(dic)
    list3= [[k,v] for k,v in dic3.items()]
    for i in range(0,len(list3)):
        temp=list3[i][0]
        list3[i][0]=list3[i][1]
        list3[i][1]=temp
    list3.sort(reverse=True)          #sort by the mean order 
    for i in range(0,len(list3)):
        temp=list3[i][0]
        list3[i][0]=list3[i][1]
        list3[i][1]=temp
    
	sorted_list3 = sorted(list3, key=lambda x: (-x[1],x[0]))

    with open(output_file_name, 'w', newline='') as csvfile:
        writer = csv.writer(csvfile)
        for i in sorted_list3:
            writer.writerows([i])

    return output_file_name        

    
#task4: down3 mean--------------------------------------------------------------DONE------------------------------------------------------
def calculate_three_worst(input_file_name,output_file_name):   
	with open(input_file_name) as f:
		rows=csv.reader(f)
		dic=OrderedDict()
		for r in rows:
			name=r[0]
			grades=[]
			for g in r[1:]:
				grades.append(int(g))
			dic.update({name: mean(grades)})

	dic3=dict(dic)
	means2=list(dic.values())
	means2.sort()
	means2=means2[:3]
	with open(output_file_name, 'w', newline='') as csvfile:
		writer = csv.writer(csvfile)
		for i in means2:
			writer.writerows([[i]])

	return output_file_name		
#--------------------------------------------------------------------------------DONE-----------------------------------------------------
#task5
def calculate_average_of_averages(input_file_name,output_file_name):   
    with open(input_file_name) as f:
        rows=csv.reader(f)
        dic=OrderedDict()
        for r in rows:
            name=r[0]
            grades=[]
            for g in r[1:]:
                grades.append(int(g))
            dic.update({name: mean(grades)})

    dic5=dict(dic)
    means5=list(dic.values())
    mean5=mean(means5)
    f = open(output_file_name, "w")
    f.write(str(mean5))

    return output_file_name
