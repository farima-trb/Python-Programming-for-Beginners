import hashlib
import csv
from collections import OrderedDict

def hash_password_hack(input_file_name, output_file_name):

    numbers=[]
    hashobj_list=[]

    #passwords
    for i in range(1000,10000):
        numbers.append(str(i))
    #hashed passwords
    for i in numbers:
        hashobj_list.append((hashlib.sha256(i.encode())).hexdigest())


    # [['danial', '99b057c8e3461b97f8d6c461338cf664bc84706b9cc2812daaebf210ea1b9974'], 
    # ['elham', '85432a9890aa5071733459b423ab2aff9f085f56ddfdb26c8fae0c2a04dce84c']]
    file_data=[]
    with open(input_file_name, newline='') as f:
        reader = csv.reader(f)
        file_data = list(reader)


    #['danial', 'elham']
    names=[]
    for i in range(0,len(file_data)):
        names.append(file_data[i][0]) 

    #[5104,9770]
    keys=[]
    for i in range(0,len(file_data)):
        for j in range(0,len(hashobj_list)):
            if file_data[i][1]==hashobj_list[j]:
                keys.append(int(numbers[j]))
        
    #[['danial', '5104'], ['elham', '9770']]
    res = [list(a) for a in zip(names, keys)]

    # OrderedDict([('danial', '5104'), ('elham', '9770')])
    hash_dict=OrderedDict(res)

    # {'danial': '5104', 'elham': '9770'}
    new_hash_dict=dict(hash_dict)

    f = open(output_file_name, "w",newline="")
    writer = csv.writer(f)
    for key, value in new_hash_dict.items():
        writer.writerow([key, value])

    return output_file_name
